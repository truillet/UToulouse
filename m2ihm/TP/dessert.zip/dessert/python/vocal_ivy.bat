pip3 install -r requirements.txt
python vocal_ivy.py
pause