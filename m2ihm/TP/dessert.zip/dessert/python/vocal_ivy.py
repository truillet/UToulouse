#!/usr/bin/env/python

from ivy.ivy import IvyServer
import pygame, sys
from pygame.locals import *
    
class Dessert_Vocal(IvyServer):
	def __init__(self, name):
		IvyServer.__init__(self,'Dessert')
		self.name = name
		self.start('127.255.255.255:2010')
		self.bind_msg(self.handle_dessert, '^sra5 Parsed=(.*)=(.*) Confidence=(.*) NP=.*')
        
	def handle_dessert(self, *arg):
		print('[Agent %s] got an item from %r'%(self.name, arg[0]))
		print(" ----> ",arg[1], "=", arg[2], " Confiance :", arg[3])
		self.send_msg('ppilot5 Say= Message reçu')
     


a=Dessert_Vocal('Dessert')
pygame.init()
fps_clock = pygame.time.Clock()
screen = pygame.display.set_mode((610,610))

bg=pygame.image.load("data/bg.jpg")	
screen.blit(bg, (0,0))
while(True):
	for event in pygame.event.get():
		if(event.type == QUIT):
			pygame.quit()
			sys.exit()
	pygame.display.update()
	fps_clock.tick(30)