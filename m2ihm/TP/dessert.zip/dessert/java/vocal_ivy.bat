java -cp .;./libivy-java-1.2.18.jar  vocal_ivy 127.255.255.255:2010
pause