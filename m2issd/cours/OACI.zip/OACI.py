#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Exercice 3 - langage OACI
import os


# définir une fonction qui encode un texte et qui renvoie le texte encodé
def encode_icao(txt):
    # definir le dictionnaire d'encodage (décalage de 3 lettres)
    ICAO = {'a':'alpha', 'b':'bravo', 'c':'charlie', 'd':'delta', 'e':'echo', 'f':'foxtrot','g':'golf','h':'hotel', 'i':'india', 'j':'juliett', 'k':'kilo','l':'lima','m':'mike','n':'november','o':'oscar','p': 'papa','q':'quebec','r':'romeo', 's':'sierra', 't':'tango', 'u':'uniform','v':'victor','w':'whiskey','x':'x-ray','y':'yankee','z':'zulu', ' ':'tiret'}
    
    # pour chacune des lettres du texte à coder
    txt_encode=''
    for i in range(len(txt)):
        # trouver sa correspondance dans le dictionnaire et écrire cette lettre dans le texte encodé
        txt_encode = txt_encode + ICAO[txt[i]] + ' '  
    return(txt_encode)


# programme principal
def main():
    # demander le teste à encoder
    texte = input("Quel est le texte à encoder ? ")
    # coder le texte 
    texte_encode = encode_icao(texte)
    # afficher le résultat
    print(" ICAO : " + texte_encode)
    
    # en faire une sortie audio 
    # os.system("espeak -ven \"" + txt_code + "\" 2>/dev/null") # UNIX - envoi des messages d'erreur à la poubelle 
    os.system("SayStatic " + texte_encode) # Windows

if __name__ == '__main__':
	main()
      

